globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/AXyhptCxcphbkVph3VJGA/_buildManifest.js",
    "static/AXyhptCxcphbkVph3VJGA/_ssgManifest.js",
    "static/AXyhptCxcphbkVph3VJGA/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/16g.ca89g7fib.js",
    "static/chunks/05sqh99f1_wo7.js",
    "static/chunks/turbopack-0v7jo45~ssozn.js"
  ]
};
