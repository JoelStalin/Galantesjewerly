var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0vs_26t.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_route_actions_0s6b5ks.js")
R.m(37245)
module.exports=R.m(37245).exports
